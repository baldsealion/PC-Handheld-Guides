Find the bios update file, such as F7A0113_sign.fd rename to BIOS.fd and put in the flash tool directory

You can find bios updates at:
https://gitlab.com/evlaV/jupiter-hw-support/-/commits/master/usr/share/jupiter_bios

Click on one such as:
https://gitlab.com/evlaV/jupiter-hw-support/-/commit/bf77354719c7a74097a23bed4fb889df4045aec4
Then scroll down to 
 usr/share/jupiter_bios/F7A0110_sign.fd → usr/share/jupiter_bios/F7A0113_sign.fd 
Click 'view file'
https://gitlab.com/evlaV/jupiter-hw-support/-/blob/bf77354719c7a74097a23bed4fb889df4045aec4/usr/share/jupiter_bios/F7A0113_sign.fd
Then click the download link next to 'open in web ide' which will download the bios update.
Rename to BIOS.fd and put it in the same folder as the flash tool.
Run in windows on the steam deck.